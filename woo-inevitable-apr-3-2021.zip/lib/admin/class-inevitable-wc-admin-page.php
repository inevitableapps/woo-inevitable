<div class="inevitable-settings">    
	<nav>
		<div class="wrapper">
			<h3>
			Inevitable - WooCommerce Mobile App Manager Settings
			</h3>
			<ul>
				<li><a target="_blank" href="https://www.raymish.com/" class="inevitable-button">Explore features</a></li>
				<li><a target="_blank" href="https://www.raymish.com/#contactus" class="inevitable-button border">Contact for License</a></li>
			</ul>
		</div>
	</nav>
	<!-- First step. show after activating plugin -->
	<?php

	$this->options = get_option( 'inevitable_wc_settings' );
	if ( ! empty( $this->options['project_id'] ) ) {
		$auto_login = false;
		$button_name     = 'Manage App';
		ob_start();
		?>
			<div class="wrapper" style="text-align: center;"> 
						<div class="connect-app-box">
							<h2>Your Online Shop is now in sync with Mobile App</h2>
							<div class="text-center">
								<p><a href="admin.php?page=inevitable-wc-admin&tab=step2">Edit Access Key</a></p>
							</div>
						</div>
			</div>
		<?php
		$html = ob_get_clean();

	}

	if ( empty( $this->options['project_id'] ) && ( empty( $_GET['tab'] ) || 'step3' === $_GET['tab'] ) ) {
		?>
			<div class="wrapper" style="text-align:center">
				<div class="connect-app-box">
					<h2>Thank you for choosing us</h2>
					<p></p>
					<div class="text-center">
						<a href="admin.php?page=inevitable-wc-admin&tab=step2" class="inevitable-button">connect store with Mobile App</a>
						or 
						<p>Know more about <a target="_blank" href="https://www.raymish.com/">Inevitable</a></p>
					</div>
				</div>
			</div>
			<!--Second step. on clicking button above will redirect to app dashboard to get access key and also advance to this step -->
		<?php
	} elseif ( ! empty( $this->options['project_id'] ) && ( empty( $_GET['tab'] ) || 'step3' === $_GET['tab'] ) ) {
						echo $html;
	}
	if ( ! empty( $_GET['tab'] ) && 'step2' === $_GET['tab'] ) {
		?>

			<div class="wrapper">

						<div class="connect-app-box">                        
						<form  method="post"  action="admin.php?page=inevitable-wc-admin&tab=step2">                        
			<?php
			// This prints out all hidden setting fields.
			settings_fields( 'inevitable_wc_key_options' );
			do_settings_sections( 'inevitable-wc-setting-admin' );
			if ( $error ) {
				printf( '<div class="text-danger"> You must fill in all of the fields. </div>' );
			}
			submit_button( 'Activate' );
			?>
						</form>
					</div>
				</div>
	<!--Final step/Success screen. Button will redirect to corresponding app-->
			<?php
	}
	?>
</div>
