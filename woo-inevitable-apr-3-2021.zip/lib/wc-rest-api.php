<?php
class INEVITABLE_WC_API extends WC_REST_Controller{

    static $_instance;

    public function __construct() {
        $this->rest_api_init();
    }


	public static function get_instance() {
		if ( ! is_a( self::$_instance, 'INEVITABLE_WC_API' ) ) {
			self::$_instance = new INEVITABLE_WC_API();
		}

		return self::$_instance;
	}

    private function rest_api_init() {
		// Init REST API routes.
		add_action( 'rest_api_init', array( $this, 'rest_api_includes' ) );
	}

    public function rest_api_includes() {
        self::write_log('Registering Rest Routes');
        register_rest_route( 'inevitable-wc/v1', '/products/categories', array(
            // 'methods' => WP_REST_Server::READABLE,
            'methods' => 'GET',
            'callback' => array( $this, 'get_categories'),
        ));
        register_rest_route( 'inevitable-wc/v1', '/products', array(
            'methods' => WP_REST_Server::READABLE,
            //'methods' => 'GET',
            'callback' => array( $this, 'get_products'),
        ));
    }

    public function get_categories($request) {
        self::write_log('Calling REST Product Categories');
        $taxonomy     = 'product_cat';

        $args           = array(
            'taxonomy'     => $taxonomy
        );

        //$all_categories = get_categories( $args );
        $query_result = get_terms( $args );
        self::write_log('Query Response');
        self::write_log($query_result);

        $response = array();
		foreach ( $query_result as $term ) {
			$data       = $this->prepare_category_item_for_response( $term, $request );
			$response[] = $this->prepare_response_for_collection( $data );
        }
        $response = rest_ensure_response( $response );
        return $response;
        // $data = [];
        // $data['username'] = 'test';
        // $data['first_name'] = 'hi';
        // return $data;
        //return $all_categories;
    }

    	/**
	 * Prepare a single product category output for response.
	 *
	 * @param WP_Term         $item    Term object.
	 * @param WP_REST_Request $request Request instance.
	 * @return WP_REST_Response
	 */
	public function prepare_category_item_for_response( $item, $request ) {
		// Get category display type.
		$display_type = get_term_meta( $item->term_id, 'display_type', true );

		// Get category order.
		$menu_order = get_term_meta( $item->term_id, 'order', true );

		$data = array(
			'id'          => (int) $item->term_id,
			'name'        => $item->name,
			'slug'        => $item->slug,
			'parent'      => (int) $item->parent,
			'description' => $item->description,
			'display'     => $display_type ? $display_type : 'default',
			'image'       => null,
			'menu_order'  => (int) $menu_order,
			'count'       => (int) $item->count,
		);

		// Get category image.
		$image_id = get_term_meta( $item->term_id, 'thumbnail_id', true );
		if ( $image_id ) {
			$attachment = get_post( $image_id );

			$data['image'] = array(
				'id'                => (int) $image_id,
				'date_created'      => wc_rest_prepare_date_response( $attachment->post_date ),
				'date_created_gmt'  => wc_rest_prepare_date_response( $attachment->post_date_gmt ),
				'date_modified'     => wc_rest_prepare_date_response( $attachment->post_modified ),
				'date_modified_gmt' => wc_rest_prepare_date_response( $attachment->post_modified_gmt ),
				'src'               => wp_get_attachment_url( $image_id ),
				'name'              => get_the_title( $attachment ),
				'alt'               => get_post_meta( $image_id, '_wp_attachment_image_alt', true ),
			);
		}
		$response = rest_ensure_response( $data );

        return $response;
    }
    
    public function get_products($request) {
        self::write_log('Calling REST All Products');
        $args = array();
        $args['post_type'] = 'product';
        $args['paged']     = $request['page'];
        $args['offset']    = $request['offset'];
        $posts_query = new WP_Query();
        $query_result = $posts_query->query( $args );
        
        self::write_log('Query Response');
        self::write_log($query_result);

        $response = array();
		foreach ( $query_result as $post ) {
			$data       = $this->prepare_product_item_for_response( $post, $request );
			$response[] = $this->prepare_response_for_collection( $data );
        }
        $response = rest_ensure_response( $response );
        return $response;
        //return $query_result;
    }

    public function prepare_product_item_for_response( $post, $request ) {
        $product  = wc_get_product( $post->ID );
        $context = 'view';
        $data = array(
			'id'                    => $product->get_id(),
			'name'                  => $product->get_name( $context ),
			'slug'                  => $product->get_slug( $context ),
			'permalink'             => $product->get_permalink(),
			'date_created'          => wc_rest_prepare_date_response( $product->get_date_created( $context ), false ),
			'date_created_gmt'      => wc_rest_prepare_date_response( $product->get_date_created( $context ) ),
			'date_modified'         => wc_rest_prepare_date_response( $product->get_date_modified( $context ), false ),
			'date_modified_gmt'     => wc_rest_prepare_date_response( $product->get_date_modified( $context ) ),
			'type'                  => $product->get_type(),
			'status'                => $product->get_status( $context ),
			'featured'              => $product->is_featured(),
			'catalog_visibility'    => $product->get_catalog_visibility( $context ),
			'description'           => 'view' === $context ? wpautop( do_shortcode( $product->get_description() ) ) : $product->get_description( $context ),
			'short_description'     => 'view' === $context ? apply_filters( 'woocommerce_short_description', $product->get_short_description() ) : $product->get_short_description( $context ),
			'sku'                   => $product->get_sku( $context ),
			'price'                 => $product->get_price( $context ),
			'regular_price'         => $product->get_regular_price( $context ),
			'sale_price'            => $product->get_sale_price( $context ) ? $product->get_sale_price( $context ) : '',
			'date_on_sale_from'     => wc_rest_prepare_date_response( $product->get_date_on_sale_from( $context ), false ),
			'date_on_sale_from_gmt' => wc_rest_prepare_date_response( $product->get_date_on_sale_from( $context ) ),
			'date_on_sale_to'       => wc_rest_prepare_date_response( $product->get_date_on_sale_to( $context ), false ),
			'date_on_sale_to_gmt'   => wc_rest_prepare_date_response( $product->get_date_on_sale_to( $context ) ),
			'price_html'            => $product->get_price_html(),
			'on_sale'               => $product->is_on_sale( $context ),
			'purchasable'           => $product->is_purchasable(),
			'total_sales'           => $product->get_total_sales( $context ),
			'virtual'               => $product->is_virtual(),
			'downloadable'          => $product->is_downloadable(),
			// 'downloads'             => $this->get_downloads( $product ),
			'download_limit'        => $product->get_download_limit( $context ),
			'download_expiry'       => $product->get_download_expiry( $context ),
			'external_url'          => $product->is_type( 'external' ) ? $product->get_product_url( $context ) : '',
			'button_text'           => $product->is_type( 'external' ) ? $product->get_button_text( $context ) : '',
			'tax_status'            => $product->get_tax_status( $context ),
			'tax_class'             => $product->get_tax_class( $context ),
			'manage_stock'          => $product->managing_stock(),
			'stock_quantity'        => $product->get_stock_quantity( $context ),
			'in_stock'              => $product->is_in_stock(),
			'backorders'            => $product->get_backorders( $context ),
			'backorders_allowed'    => $product->backorders_allowed(),
			'backordered'           => $product->is_on_backorder(),
			'sold_individually'     => $product->is_sold_individually(),
			'weight'                => $product->get_weight( $context ),
			'dimensions'            => array(
				'length' => $product->get_length( $context ),
				'width'  => $product->get_width( $context ),
				'height' => $product->get_height( $context ),
			),
			'shipping_required'     => $product->needs_shipping(),
			'shipping_taxable'      => $product->is_shipping_taxable(),
			'shipping_class'        => $product->get_shipping_class(),
			'shipping_class_id'     => $product->get_shipping_class_id( $context ),
			'reviews_allowed'       => $product->get_reviews_allowed( $context ),
			'average_rating'        => wc_format_decimal( $product->get_average_rating(), 2 ),
			'rating_count'          => $product->get_rating_count(),
			'related_ids'           => array_map( 'absint', array_values( wc_get_related_products( $product->get_id() ) ) ),
			'upsell_ids'            => array_map( 'absint', $product->get_upsell_ids( $context ) ),
			'cross_sell_ids'        => array_map( 'absint', $product->get_cross_sell_ids( $context ) ),
			'parent_id'             => $product->get_parent_id( $context ),
			'purchase_note'         => wpautop( do_shortcode( wp_kses_post( $product->get_purchase_note() ) ) ),
			// 'categories'            => $this->get_taxonomy_terms( $product ),
			// 'tags'                  => $this->get_taxonomy_terms( $product, 'tag' ),
			// 'images'                => $this->get_images( $product ),
			// 'attributes'            => $this->get_attributes( $product ),
			// 'default_attributes'    => $this->get_default_attributes( $product ),
			'variations'            => array(),
			'grouped_products'      => array(),
			'menu_order'            => $product->get_menu_order( 'view' ),
			'meta_data'             => $product->get_meta_data(),
		);

		return $data;
    }

    public function write_log($log) {
        if (true === WP_DEBUG) {
            if (is_array($log) || is_object($log)) {
                error_log(print_r($log, true));
            } else {
                error_log($log);
            }
        }
    }

}
