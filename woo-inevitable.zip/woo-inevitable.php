<?php
/**
 * Plugin Name: Inevitable - WooCommerce Mobile App Manager
 * Plugin URI: https://www.raymish.com
 * Description: Inevitable WooCommerce App plugin helps build WooCommerce Android and iOS Mobile App for your E-Commerce Website
 * Version: 1.0.0
 * Author: inevitable
 * Author URI: https://www.raymish.com
 * 
 * WC requires at least: 4.1.0
 * WC tested up to: 4.1.0
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

require __DIR__ . '/jwt-auth.php';

class INEVITABLE_WC {
    public static function init() {
        register_deactivation_hook( __FILE__, array( self::name(), 'deactivate' ) );
        register_uninstall_hook( __FILE__, array( self::name(), 'uninstall' ) );
		// require_once dirname( __FILE__ ) . '/lib/wc-rest-api.php';
		if ( is_admin() ) {
			require_once dirname( __FILE__ ) . '/lib/admin/class-inevitable-wc-options.php';
		}
		// INEVITABLE_WC_API::get_instance();
		add_filter( 'woocommerce_rest_check_permissions', array( self::name(), 'changeWooPermissions') , 10, 4 );
		add_filter( 'user_has_cap', array( self::name(), 'allow_payment_without_login'), 10, 3 );
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__  ), array( self::name(), 'plugin_action_links') );
		add_action( 'woocommerce_update_order', array( self::name(), 'inevitable_order_details' ), 2, 1 );
		add_action( 'woocommerce_init', array( self::name(), 'force_non_logged_user_wc_session'));

	}

    public static function name() {
		return 'INEVITABLE_WC';
    }
    /**
	 * Plugin uninstall hook
	 */
	public static function uninstall() {
		delete_option( 'inevitable_wc_settings' );
		do_action( 'INEVITABLE_WC_Plugin_uninstall' );
	}

	/**
	 * Plugin deactivate hook
	 */
	public static function deactivate() {
		do_action( 'INEVITABLE_WC_Plugin_deactivate' );
	}

	/**
	 * Add more links to plugin's "row" in the WordPress' plugin list,
	 * for more actions that user can do.
	 *
	 * @param array $links A list of links already registered.
	 * @return array
	 */
	public static function plugin_action_links( $links ) {
		$plugin_links = [];

		if ( function_exists( 'wc' ) ) {
			$plugin_links[] = '<a href="admin.php?page=inevitable-wc-admin">' . __( 'Settings', '' ) . '</a>';
		}

		$plugin_links[] = '<a href="https://www.raymish.com/#contactus">' . __( 'Support', '' ) . '</a>';

		return array_merge( $plugin_links, $links );
	}

	/**
	 * @param $order_id
	 */
	public static function inevitable_order_details( $order_id ) {
		if ( ! $order_id ) {
			return;
		} elseif ( !is_admin() ) {
			$order = wc_get_order( $order_id );
			if ( is_a( $order, 'WC_Order' ) ) {
				if ( ! get_post_meta( $order_id, 'from_app' ) ) {
					$order->add_order_note( __( 'Order from App', 'inevitable-app-manager' ) );
					add_post_meta( $order_id, 'from_app', true );
				}
				//$key = method_exists( $order, 'get_order_key' ) ? $order->get_order_key() : $order->order_key;
				//WC()->session->set( 'last_order_key', $key );
			}
		}
	}

	public static function force_non_logged_user_wc_session()
	{
		if (is_user_logged_in() || is_admin())
			return;
		if (isset(WC()->session)) {
			if (!WC()->session->has_session()) {
				WC()->session->set_customer_session_cookie(true);
			}
		}
	}

	public static function allow_payment_without_login( $allcaps, $caps, $args ) {
		// Check we are looking at the WooCommerce Pay For Order Page
		//self::write_log('$caps[0]');
		//self::write_log($caps[0]);
		if ( !isset( $caps[0] ) || $caps[0] != 'pay_for_order' )
			return $allcaps;
		// Check that a Key is provided
		if ( !isset( $_GET['key'] ) )
			return $allcaps;
	
		// Find the Related Order
		//self::write_log('$args[2]');
		//self::write_log($args[2]);
		$order = wc_get_order( $args[2] );
		if( !$order )
			return $allcaps; # Invalid Order
	
		// Get the Order Key from the WooCommerce Order
		$order_key = $order->get_order_key();
		// Get the Order Key from the URL Query String
		$order_key_check = $_GET['key'];
		//self::write_log('$order_key');
		//self::write_log($order_key);

		//self::write_log('$order_key_check');
		//self::write_log($order_key_check);
	
		// Set the Permission to TRUE if the Order Keys Match
		$allcaps['pay_for_order'] = ( $order_key == $order_key_check );
	
		return $allcaps;
	}

	public static function changeWooPermissions( $permission, $context, $object_id, $type ) {
		self::write_log('Site Name');
		$siteName  = get_option( 'blogname' );
		self::write_log($siteName);
		
		$options = get_option( 'inevitable_wc_settings' );
		if($options)
		{
			$project_id = $options['project_id'];
			self::write_log('$project_id');
			self::write_log($project_id);
			$api_key = $options['api_key'];
			self::write_log('$api_key');
			self::write_log($api_key);
			$api_secret = $options['api_secret'];
			self::write_log('$api_secret');
			self::write_log($api_secret);
		}

		self::write_log('changeWooPermissions');
		self::write_log('permission');
		self::write_log($permission);
		self::write_log('context');
		self::write_log($context);
		self::write_log('object_id');
		self::write_log($object_id);
		self::write_log('type');
		self::write_log($type);

		$request_headers = self::get_headers();
		self::write_log('get_headers');
		self::write_log($request_headers);

		$apiKeyCheckRequired = false;

		if ( ($type === 'user') || ($type === 'product' && $context === 'read') 
			|| ($type === 'product_cat' && $context === 'read') 
			|| ($type === 'settings' && $context === 'read') 
			|| ($type === 'shipping_methods' && $context === 'read') 
			|| ($type === 'payment_gateways' && $context === 'read') 
			|| ($type === 'shop_order' && $context === 'create') 
			|| ($type === 'shop_order' && $context === 'read') 
			) {
				$apiKeyCheckRequired = true;
		}
		self::write_log('$apiKeyCheckRequired');
		self::write_log($apiKeyCheckRequired);
		//Check if API Key is matching

		if($apiKeyCheckRequired && $options)
		{
			if(! isset($request_headers['Api_key']))
			{
				self::write_log('$request_headers[Api_key] is NOT set in the Request');
				//return false;
				return $permission;
			}
			if ( strcmp($request_headers['Api_key'], $api_key) === 0) 
			{
				self::write_log('API Key Is matching');
				self::write_log('$api_key');
				self::write_log($api_key);
				self::write_log('$request_headers[Api_key]');
				self::write_log($request_headers['Api_key']);
			}
			else
			{
				self::write_log('API Key Is Not matching. Permission Denied!');
				self::write_log('$api_key');
				self::write_log($api_key);
				self::write_log('$request_headers[Api_key]');
				self::write_log($request_headers['Api_key']);
				//return false;
				return $permission;
			}
		}
		if($apiKeyCheckRequired && ! $options)
		{
			self::write_log('Connect the Store with Inevitable App');
			//return false;
			return $permission;
		}


		// Only allow the logged-in user to see his own profile
		if ($type === 'user') {
			$current_user_id = get_current_user_id();
			return $current_user_id === $object_id;
		}
		//Reading Product is Allowed
		if($type === 'product' && $context === 'read')
		{
			return true;
		}
		//Reading Product Category is Allowed
		if($type === 'product_cat' && $context === 'read')
		{
			return true;
		}
		//Reading Settings - Shipping Zones, Locations is Allowed
		if($type === 'settings' && $context === 'read')
		{
			return true;
		}
		//Reading Shipping Methods is Allowed
		if($type === 'shipping_methods' && $context === 'read')
		{
			return true;
		}
		//Reading Payment Gateways is Allowed
		if($type === 'payment_gateways' && $context === 'read')
		{
			return true;
		}
		//Creating Shopping Order is Allowed
		if($type === 'shop_order' && $context === 'create')
		{
			return true;
		}
		//Reading Shopping Order is Allowed
		if($type === 'shop_order' && $context === 'read')
		{
			return true;
		}
		return $permission;
	}

	public static function write_log($log) {
        if (true === WP_DEBUG) {
            if (is_array($log) || is_object($log)) {
                error_log(print_r($log, true));
            } else {
                error_log($log);
            }
        }
	}
	
	  // helper to try to sort out headers for people who aren't running apache
	  public static function get_headers() {
		if (function_exists('apache_request_headers')) {
		  // we need this to get the actual Authorization: header
		  // because apache tends to tell us it doesn't exist
		  $headers = apache_request_headers();
	
		  // sanitize the output of apache_request_headers because
		  // we always want the keys to be Cased-Like-This and arh()
		  // returns the headers in the same case as they are in the
		  // request
		  $out = array();
		  foreach ($headers AS $key => $value) {
			$key = str_replace(
				" ",
				"-",
				ucwords(strtolower(str_replace("-", " ", $key)))
			  );
			$out[$key] = $value;
		  }
		} else {
		  // otherwise we don't have apache and are just going to have to hope
		  // that $_SERVER actually contains what we need
		  $out = array();
		  if( isset($_SERVER['CONTENT_TYPE']) )
			$out['Content-Type'] = $_SERVER['CONTENT_TYPE'];
		  if( isset($_ENV['CONTENT_TYPE']) )
			$out['Content-Type'] = $_ENV['CONTENT_TYPE'];
	
		  foreach ($_SERVER as $key => $value) {
			if (substr($key, 0, 5) == "HTTP_") {
			  // this is chaos, basically it is just there to capitalize the first
			  // letter of every word that is not an initial HTTP and strip HTTP
			  // code from przemek
			  $key = str_replace(
				" ",
				"-",
				ucwords(strtolower(str_replace("_", " ", substr($key, 5))))
			  );
			  $out[$key] = $value;
			}
		  }
		}
		return $out;
	  }
}

add_action( 'plugins_loaded', array( 'INEVITABLE_WC', 'init' ) );